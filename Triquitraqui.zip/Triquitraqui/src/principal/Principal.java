
package principal;

import vista.FormInicio;


public class Principal {
    public static void main(String[] args) {
        
        FormInicio formInicio = new FormInicio();
        formInicio.setVisible(true);
        
    }
}
