
package modelo;


public enum TipoImagen {
    EQUIS, CIRCULO, LINEA1, LINEA2, LINEA3, LINEA4, LINEA5, LINEA6, LINEA7, LINEA8,EMPATE
}
